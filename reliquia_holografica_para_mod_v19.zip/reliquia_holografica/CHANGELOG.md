# Registro de cambios (resumen)

- **v1-v3** Primer modelo (núcleo cian, anillos y fragmentos), animaciones base, reducción de tamaño y aura.
- **v4-v5** Efectos intermitentes dentro de `idle`, núcleo compacto y voxelizado, estelas finas, rayos y micro-glitch.
- **v6-v8** Fusión de cubos contiguos, GIF de previsualización, geometría centrada para el mod, textura emisiva selectiva.
- **v9** Estelas y anillos como líneas de cuentas sobre curvas exactas (sin escalones), polvo de píxeles, variante lite.
- **v10** QC de movimiento (`qc_motion.py`), vistas desde varios ángulos.
- **v11** Reposo limpio (efectos ocultos dentro del núcleo), sprites de luz para halos/destello/ondas (bloom horneado), sin bloques largos.
- **v12** Núcleo definido (se elimina el aura de cubos), halo amplio tenue.
- **v13** Rediseño: esfera armilar (tres anillos graduados) y cuatro cristales orbitales.
- **v14** Grosor mínimo de piezas finas para legibilidad a distancia.
- **v15** `charge_up`, `charge_down`, `hit`; precesión coherente de los planos.
- **v16** Reescritura de animaciones: corrección del enlace de `relic_root` en el .bbmodel, activación/desactivación por fases, empalmes con continuidad de velocidad, capas `layer_*`, `idle` de 48 s.
- **v17** `energy_pulse` por fases, `release`, `wake`/`sleep`, `idle_dormant` vivo.
- **v18** Estado de alerta (`idle_alert`, `alert_up`, `alert_down`); modulación de giro escalada con el periodo.
- **v19** Manifiesto legible por máquina y animación alternativa solo lineal.

Los scripts de cada versión anterior están en `tools/historial/`.
