# PROMPT PARA LA IA QUE HARÁ EL MOD

Copia todo lo de abajo y pásalo a la IA, junto con la carpeta `reliquia_holografica/` (o el .zip).

---

Actúa como desarrollador senior de mods de Minecraft Forge. Quiero que **construyas tú el mod completo**, con archivos reales, sin darme tutoriales. Si necesitas algo de mí, pídeme solo esa cosa concreta y sigue con el resto.

## 1. Objetivo
Un mod para **Minecraft Java 1.20.1, Forge, Java 17**, que añada una **reliquia cosmética** (un ítem accesorio vía **Curios API**) que se muestre como un núcleo holográfico de luz azul flotando detrás del jugador, ligeramente sobre un hombro, con estelas de luz orbitales a su alrededor. El modelo, las texturas y las animaciones ya están hechos (ver sección 3). **No debes rehacerlos ni modificarlos.** Tu trabajo es todo lo demás: proyecto Gradle, registro del ítem, integración con Curios, renderizado, control de animaciones, brillo, lang, receta y recursos.

## 2. Reglas importantes
- **Verifica las versiones.** Elige y declara las versiones concretas y compatibles de Forge 1.20.1, Curios API y GeckoLib 4 para 1.20.1 (consúltalas, no las inventes ni las recuerdes de memoria). Si una API que menciono aquí no existe con ese nombre en esa versión, dime cuál es la equivalente real.
- No inventes compatibilidades: si algo no se puede hacer como pido, dilo y propón la alternativa más cercana.
- Código limpio, comentado donde no sea obvio, sin dependencias innecesarias. Debe compilar (`gradlew build`) y arrancar con `runClient`.
- Entrega la estructura completa del proyecto, y al final una lista corta de qué probar en el juego.

## 3. Assets existentes (no modificar)
Estructura de la carpeta entregada:
- `export/geo/relic_hologram_centered.geo.json` — **geometría recomendada para el mod**: el origen (0,0,0) es el centro del núcleo. Identificador `geometry.relic_hologram_centered`.
- `export/geo/relic_hologram_lite_centered.geo.json` — variante ligera (~620 cubos en vez de ~1035) con **los mismos huesos y las mismas animaciones**: solo le faltan los fantasmas de glitch, anillos armilares 5-6, ondas, píxeles a la deriva y partículas orbitales. Úsala como opción de calidad "baja" en la config (cargando uno u otro .geo.json, sin tocar las animaciones).
- `export/geo/relic_hologram.geo.json` — la misma geometría anclada al hombro (centro en (-6, 30, 8) px respecto al origen del modelo de jugador de Blockbench); solo para previsualizar en Blockbench junto a un jugador. **No usar en el mod**: si el renderer de accesorios parte de otro origen (p. ej. el torso, no los pies), el objeto aparece flotando lejos del hombro.
- `export/animations/relic_hologram.animation.json` — animaciones (formato 1.8.0).
- `export/animations/relic_hologram.animation.linear.json` — **la misma animación solo con interpolación lineal** (las curvas suaves están muestreadas cada 0,25 s). Úsala si la versión de GeckoLib elegida no soporta `lerp_mode: catmullrom` o si ves que las curvas se comportan raro.
- `export/relic_manifest.json` — **manifiesto legible por máquina**: rutas de geometría/texturas, identificadores, lista de las 20 animaciones con duración, bucle, tipo (`state_loop`, `transition`, `oneshot_returns_to_current_state`, `layer`) y estado siguiente, huesos de efectos, offset recomendado y ticks de transición. **Léelo primero y genera las constantes del mod a partir de él** en lugar de copiar nombres a mano.
- `textures/relic_hologram.png` — atlas 64x96: arriba, paleta en celdas de 8x8; abajo, cuatro **sprites de luz de 32x32 con alfa** (halo suave, estrella de destello, anillo de onda y halo amplio tenue) usados por planos finos (`core_halo`, `hh_*` = halos en las cabezas de las estelas, `flash`, `wave_*`, brillo de los cometas). Para que se vean como luz, el render debe usar un RenderType **translúcido y sin sombreado (fullbright)**, con textura emisiva.
- `textures/relic_hologram_glowing.png` — textura para la capa emisiva (brillo): igual que la principal pero con el halo translúcido tenue (aura) sin brillo propio.
- `source/relic_hologram.bbmodel` — fuente de Blockbench (solo referencia; si el modelo se ve espejado o las rotaciones salen invertidas con los JSON, indícalo: se pueden reexportar desde Blockbench).

Colócalos donde corresponda según la convención de GeckoLib 4 (por ejemplo `assets/<modid>/geo/`, `animations/`, `textures/`) y ajusta rutas y `modid` tú mismo. Puedes elegir el modid (propón uno corto, en minúsculas).

### Huesos (jerarquía)
`relic_react` (envoltorio superior, sin geometría; solo lo mueven las animaciones `layer_*`) > `relic_root` > `core` (`core_inner`, `core_mid`, `glitch_shell` > `core_shell` > `sh_d`/`sh_m`/`sh_u`, `core_debris` > `sp_a..sp_d`, `glitch_aura` > `core_aura` > `aura_a`/`aura_b`/`aura_c`, vacíos desde la v12 y conservados solo por compatibilidad con las animaciones) · `core_halo` (halo de bloom horneado: 3 planos con sprite) > `core_halo2` (halo amplio y tenue) · `hh_trail1..3` (halos en las cabezas de las estelas) · `ring_tilt_N` > `ring_spin_N` (N = 1..7: 1-3 son estelas de energía, 4-6 anillos armilares (esfera armilar) con marcas, marco azul oscuro y gemas, y 7 lleva los cuatro cristales orbitales `shard_1..4`) · `frag_tilt_a`/`b` > `frag_orbit_a`/`b` > `fo_a0..2`/`fo_b0..2` (partículas que orbitan en la misma corriente que las estelas 1 y 3) · `drift_01..10` · **efectos intermitentes**: `bolt_01..08` (rayos), `comet_tilt_1/2` > `comet_1/2`, `wave_tilt_a/b` > `wave_a/b`, `burst_01..16` (chispas), `ghost_a`/`ghost_b` (duplicados de glitch), `flash`.

### Animaciones (nombres exactos)
| Nombre | Duración | Tipo | Uso |
|---|---|---|---|
| `animation.relic.idle` | 48 s | loop | Estado normal (equipada y activa). **Lleva efectos intermitentes ya horneados en la línea de tiempo** (ver abajo; dos secuencias distintas de 24 s para que no se note la repetición) |
| `animation.relic.idle_charged` | 12 s | loop | Estado "cargado" (p. ej. en combate): giros al doble de velocidad, pulso más rápido y rayos/glitch/ondas frecuentes |
| `animation.relic.idle_alert` | 8 s | loop | Estado de alerta (p. ej. enemigos cerca): giros 1.5× más rápidos, pulso más vivo, ondas de escaneo cada pocos segundos y campanada de los cristales |
| `animation.relic.idle_calm` | 12 s | loop | Igual que `idle` pero sin efectos intermitentes (para una opción de config "efectos reducidos") |
| `animation.relic.idle_dormant` | 12 s | loop | Estado inactivo/apagado |
| `animation.relic.activation` | 3.6 s | una vez | Al activarse; termina en la pose de `idle` |
| `animation.relic.deactivation` | 2.6 s | una vez | Al desactivarse; termina en la pose de `idle_dormant` |
| `animation.relic.wake` | 1.5 s | una vez | Versión rápida de `activation` (misma coreografía comprimida) para alternar a menudo; termina en `idle` |
| `animation.relic.sleep` | 1.3 s | una vez | Versión rápida de `deactivation`; termina en `idle_dormant` |
| `animation.relic.energy_pulse` | 2.8 s | una vez | Pulso de energía puntual; termina en la pose de `idle` |
| `animation.relic.glitch` | 1 s | una vez | Parpadeo breve; termina en la pose de `idle` |
| `animation.relic.charge_up` | 1.6 s | una vez | Transición de `idle`/`idle_calm` a `idle_charged` (carga progresiva, termina en la pose de reposo) |
| `animation.relic.charge_down` | 1.8 s | una vez | Transición de `idle_charged` a `idle` (los giros frenan, termina en la pose de reposo) |
| `animation.relic.alert_up` | 1.6 s | una vez | Transición de `idle`/`idle_calm` a `idle_alert` (los anillos se tensan; termina en la pose de reposo) |
| `animation.relic.alert_down` | 1.8 s | una vez | Transición de `idle_alert` a `idle` |
| `animation.relic.hit` | 0.6 s | una vez | Reacción al recibir un golpe el portador (retroceso, destello, rayos); termina en la pose de reposo |
| `animation.relic.release` | 3.4 s | una vez | Habilidad especial / liberación total: carga creciente (todo se recoge hacia el núcleo), explosión con ondas, cometas y rayos, y retroceso con rebotes; termina en `idle` |
| `animation.relic.layer_hit` | 0.6 s | capa, una vez | Retroceso y aplastamiento al recibir un golpe; **solo anima `relic_react`**, para reproducirse en un segundo controlador sobre cualquier reposo |
| `animation.relic.layer_bump` | 1.0 s | capa, una vez | Rebote hacia arriba (p. ej. al recoger algo o subir de nivel); solo `relic_react` |
| `animation.relic.layer_shake` | 0.9 s | capa, una vez | Sacudida que se amortigua (daño fuerte); solo `relic_react` |

**Máquina de estados sugerida**: sin equipar → nada; al equipar: `activation` → `idle` (loop); alternar con la tecla: `deactivation` → `idle_dormant` (loop) y `activation` al volver; estado de combate: `charge_up` → `idle_charged` (loop) y, al terminar, `charge_down` → `idle`; estado de alerta (enemigos cerca): `alert_up` → `idle_alert` (loop) y `alert_down` → `idle` al terminar; al recibir daño: `hit` → volver al reposo que tocara; pulso breve: `energy_pulse` → reposo; habilidad especial: `release` → reposo; para alternar activo/dormant con frecuencia usa `wake` / `sleep` (versiones rápidas) en lugar de `activation` / `deactivation`. Todas las animaciones de una sola vez terminan en una pose compatible con el inicio de los reposos, así que se pueden encadenar sin saltos (conviene una transición corta de unos pocos ticks). **Capas**: las animaciones `layer_*` solo tocan el hueso `relic_react`, así que deben reproducirse en un SEGUNDO `AnimationController` simultáneo al del reposo (no sustituyen al reposo y no provocan saltos en los giros). Las animaciones de una sola vez que sí sustituyen al reposo (`activation`, `deactivation`, `energy_pulse`, `charge_*`, `hit`) están construidas para empalmar con la **velocidad de giro** de los reposos, pero el ángulo de cada anillo al entrar depende de la fase del reposo anterior, así que usa una transición de 4 a 8 ticks entre animaciones.

Efectos intermitentes dentro de `idle` (no requieren código): rayos t=2 s, campanada de los cristales t=3 s, cometa t=4 s, micro-glitch t=6.5 s, ráfaga de chispas t=8 s, rayos t=10 s, onda de energía + oleada de aura t=12 s, micro-glitch t=14.2 s, cometa inverso t=15.5 s, rayos t=16.8 s, destello del núcleo t=18.5 s, micro-glitch t=20.2 s, onda vertical + ondulación de estelas t=21 s. Un solo AnimationController basta. En la segunda mitad del bucle (24-48 s) la secuencia es distinta: otros rayos, cometas en sentido contrario, y ondas, destellos y micro-glitches en otros momentos.

Notas técnicas del modelo:
- **Pose de reposo limpia**: los huesos de efectos (`bolt_*`, `comet_tilt_*`, `wave_tilt_*`, `flash`, `ghost_*`, `burst_*`) están dibujados en miniatura DENTRO del núcleo (ocultos por sus capas opacas) y las animaciones los escalan (×5; los `ghost_*` ×3) solo cuando aparecen. No hay que ocultarlos por código ni cambiar sus escalas. `glitch_shell` y `glitch_aura` son envoltorios sin geometría propia que solo se mueven durante los micro-glitch.
- **Colocación**: usa `relic_hologram_centered.geo.json` y coloca el núcleo con un offset configurable respecto al hombro del jugador. Punto de partida (en píxeles de modelo, es decir 1/16 de bloque): 6 px hacia el lado del hombro elegido, unos 6 px por encima de la línea de hombros y unos 6 px por detrás de la cara trasera del torso (equivale a (-6, +6 sobre hombros, +8 atrás desde el centro del torso) en el espacio de Blockbench, donde Z+ = espalda; **verifica la convención de ejes y de signo del renderer que uses**, porque las de Minecraft (Y hacia abajo en las partes del jugador) difieren de las de GeckoLib/Blockbench). Haz configurable el hombro (izquierdo/derecho; para el otro hombro, espejar X), el offset (x, y, z) y la escala.
- **Ajuste en vivo**: añade un comando de cliente (p. ej. `/relic offset <x> <y> <z>`, `/relic scale <s>`, `/relic side <left|right>`) que cambie esos valores al instante y muestre los valores actuales en el chat, para afinar la posición jugando y copiar los números definitivos a la config.
- El modelo es pequeño a propósito (unos 11 px de ancho en total; las ondas de energía se expanden hasta unos 10 px de diámetro durante un instante). Expón una escala configurable.
- Textura con alfa: las piezas translúcidas (estelas, cáscara, aura) usan transparencia de la propia textura.

## 4. Funcionalidad que debes implementar
1. **Ítem accesorio Curios** (propón un slot adecuado, p. ej. `charm` o uno propio tipo "relic"/"back", y registra el tag/slot con los datos necesarios de Curios en datapack). Máximo 1 equipada. Sin textura de ítem complicada: usa un icono sencillo (puedes generar un PNG 16x16 azul con script) y modelo de ítem plano.
2. **Renderizado en el jugador** mediante el sistema de renderizado de Curios para accesorios (`ICurioRenderer` o el mecanismo equivalente de la versión que elijas) con **GeckoLib 4**. Debe verse en tercera persona y en el modelo del jugador de otros jugadores (multijugador), **no** tapar la vista en primera persona. Debe seguir la rotación del cuerpo y ajustarse al agacharse (sneak) como un accesorio de espalda/hombro; evita que atraviese la armadura o la capa de forma exagerada.
3. **Máquina de estados de animación** (AnimationController de GeckoLib):
   - Al equipar: `activation` → luego `idle`.
   - Al desequipar: no se renderiza más (si es viable, deja que se vea `deactivation` brevemente; si no, omítelo y dímelo).
   - Un comando o tecla configurable (propón: un keybind) que alterna entre estado activo (`idle`) y dormant (`activation`/`deactivation` + `idle_dormant`).
   - Disparar `energy_pulse` con una acción concreta (propón una: p. ej. al subir de nivel o con un comando `/relic pulse`), y `glitch` de forma ocasional aleatoria cada cierto intervalo configurable (por defecto 20-60 s) solo mientras está en `idle`.
   - Las transiciones entre animaciones deben ser suaves (cuidado: `activation`, `deactivation`, `energy_pulse` y `glitch` están diseñadas para empezar/terminar en poses compatibles con `idle`/`idle_dormant`).
4. **Brillo (glow).**
   - Renderiza el modelo con la capa emisiva: usa `textures/relic_hologram_glowing.png` con el mecanismo de capas brillantes de GeckoLib 4 (confirma el nombre de clase y la convención de sufijo de textura de la versión elegida), o, si no encaja con el renderizado de Curios, implementa el modelo en *fullbright* (luz máxima, sin sombreado) con `RenderType` translúcido/emisivo.
   - El objeto debe verse **luminoso incluso de noche y en cuevas**.
   - Comprueba y documenta cómo se comporta con shaders (Iris/Oculus) y, si un mod de bloom o de render avanzado puede añadir resplandor real, deja un punto de integración opcional sin hacerlo obligatorio. No introduzcas dependencias obligatorias de shaders.
5. **Obtención**: receta de crafteo sencilla pero temática (propón una con materiales vanilla) y entrada en la pestaña creativa.
6. **Lang** en español (es_es) e inglés (en_us). Nombre propuesto: "Núcleo Holográfico" / "Holographic Core".
7. **Rendimiento**: el modelo tiene ~975 cubos (~750 en la variante lite; los halos son planos de luz). Evita recalcular nada pesado cada tick; ofrece una opción de config para reducir calidad (usa la variante `lite` de la geometría y `idle_calm`) si es técnicamente sencillo.

## 5. Qué entregar
- Proyecto Gradle completo y compilable (`build.gradle`, `mods.toml`, `pack.mcmeta`, código Java, recursos, datapack de Curios, lang, recetas).
- Los assets copiados en sus rutas correctas.
- Un `README` corto: cómo compilar, cómo probar y los parámetros de configuración.
- Una checklist final de pruebas: equipar/desequipar, activación/desactivación, sneak, primera persona, multijugador, de noche/cueva, y con/sin shaders.

Empieza ya: primero indica en 5 líneas máximo las versiones que elegiste y por qué, y luego genera el proyecto.
