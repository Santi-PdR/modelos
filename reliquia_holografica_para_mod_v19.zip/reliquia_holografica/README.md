# Reliquia holográfica v19 (manifiesto para el mod y animación alternativa solo lineal)

- `source/relic_hologram.bbmodel` — fuente editable (modelo + 20 animaciones + textura embebida). Abrir en Blockbench.
- `export/geo/relic_hologram_centered.geo.json` — **la que debe usar el mod** (origen = centro del núcleo; el offset hacia el hombro se aplica desde el código). `export/geo/relic_hologram.geo.json` es la misma anclada al hombro (solo para previsualizar con un jugador en Blockbench). Y `export/animations/relic_hologram.animation.json` — formato Bedrock (geo 1.12.0 / anim 1.8.0), generados por script. Verifícalos al importarlos; si algo difiere, reexporta desde el .bbmodel con Blockbench.
- `export/geo/relic_hologram_lite_centered.geo.json` — variante ligera (~620 cubos) con los mismos huesos: opción de calidad baja para el mod.
- `export/animations/relic_hologram.animation.linear.json` — animación equivalente solo con interpolación lineal (alternativa segura si el motor no soporta catmullrom).
- `export/relic_manifest.json` — manifiesto legible por máquina (rutas, animaciones, tipos, transiciones, huesos de efectos).
- `textures/relic_hologram.png` (64x96: paleta + 3 sprites de luz) y `relic_hologram_glowing.png` (capa emisiva: igual que la principal pero sin el halo tenue).
- `preview/preview_idle.png` (estado normal) y `preview_efectos.png` (todos los efectos a la vez, composición estática) `preview_animacion.png` (fotogramas reales de `idle` en los momentos de cada efecto).
- `preview/preview_angulos.png` — silueta en reposo desde 6 ángulos (equilibrio visual).
- `preview/anim_*.gif` — animaciones reproducidas fotograma a fotograma desde las keyframes (idle, idle_charged, energy_pulse, activation, deactivation, glitch). Se regeneran con `python3 tools/make_gif.py <animacion> <fps> [tamaño]`.
- `PROMPT_MOD_PARA_IA.md` — prompt listo para que otra IA construya el mod (Forge 1.20.1 + Curios + GeckoLib).
- `CHANGELOG.md` — resumen de cambios por versión.
- `tools/build_relic.py` — regenera todo (`python3 build_relic.py`; escala global en `K`). `tools/historial/build_relic_v1..v18.py`; `tools/audit_model.py` audita bloques largos, piezas visibles en reposo y grupos sin animación; `tools/qc_motion.py` revisa saltos por fotograma, costuras de bucle, rebotes de las curvas y la continuidad de velocidad en los empalmes; `tools/make_views.py` genera las vistas son versiones anteriores.

## Jerarquía
relic_root > core (core_inner, core_mid, glitch_shell > core_shell > sh_d/m/u, core_debris > sp_a..d, glitch_aura > core_aura > aura_a/b/c) · ring_tilt_N > ring_spin_N (1-3 estelas, 4-6 anillos armilares, 7 cristales shard_1..4) · frag_tilt_a/b > frag_orbit_a/b > fo_a0..2/fo_b0..2 · drift_01..10 · bolt_01..08 · comet_tilt_1/2 > comet_1/2 · wave_tilt_a/b > wave_a/b · burst_01..16 · ghost_a/b · flash

## Animaciones
`idle` (24 s, loop, con efectos intermitentes), `idle_calm` (12 s, sin efectos), `idle_charged` (12 s, intenso), `idle_alert` (8 s, alerta), `idle_dormant` (12 s, con micro-parpadeos y chispazos diminutos), `energy_pulse` (2.8 s, por fases), `activation` (3.6 s, por fases: despertar, ignición, despliegue, asentamiento), `deactivation` (2.6 s, fallo de energía y colapso hasta dormant), `glitch` (1 s), `charge_up` (1.6 s), `charge_down` (1.8 s), `alert_up` (1.6 s), `alert_down` (1.8 s), `hit` (0.6 s), `wake` (1.5 s) y `sleep` (1.3 s) rápidos, `release` (3.4 s, habilidad especial); capas (solo mueven `relic_react`, para un segundo controlador): `layer_hit`, `layer_bump`, `layer_shake`.

Los efectos intermitentes están dibujados en miniatura dentro del núcleo en la pose de reposo (ocultos) y las animaciones los escalan al aparecer. Núcleo en (-6, 30, 8): sobre un hombro y detrás del jugador (Z+ = espalda); para el otro hombro, espejar X.
