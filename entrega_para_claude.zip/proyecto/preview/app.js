/* Visor de la capa — renderer software en canvas puro.
   Port de tools/preview_cloth.py: mismas matrices, mismas caras, mismo atlas.
   NO es una captura in-game: es la geometría real del geo de Blockbench. */

const GEO_URL = 'assets/armor.geo.json';
const ATLAS_URL = 'assets/armor.png';

let GEO = null, ATLAS = null, ATLAS_W = 128, ATLAS_H = 128;
const canvas = document.getElementById('view');
const ctx = canvas.getContext('2d', { alpha: false });
let SIZE = 480;

/* ---------- álgebra 4x4 (row-major) ---------- */
function ident() { return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]; }
function mul(a, b) {
  const o = new Array(16);
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    let s = 0;
    for (let k = 0; k < 4; k++) s += a[i*4+k] * b[k*4+j];
    o[i*4+j] = s;
  }
  return o;
}
function T(v) { const m = ident(); m[3]=v[0]; m[7]=v[1]; m[11]=v[2]; return m; }
function R(axis, deg) {
  const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a), m = ident();
  if (axis === 'x') { m[5]=c; m[6]=-s; m[9]=s; m[10]=c; }
  else if (axis === 'y') { m[0]=c; m[2]=s; m[8]=-s; m[10]=c; }
  else { m[0]=c; m[1]=-s; m[4]=s; m[5]=c; }
  return m;
}
function rotmat(r) { return mul(mul(R('z', r[2] || 0), R('y', -(r[1] || 0))), R('x', -(r[0] || 0))); }
function apply(M, v) {
  return [M[0]*v[0]+M[1]*v[1]+M[2]*v[2]+M[3],
          M[4]*v[0]+M[5]*v[1]+M[6]*v[2]+M[7],
          M[8]*v[0]+M[9]*v[1]+M[10]*v[2]+M[11]];
}

/* ---------- huesos ---------- */
const SECTION_BONES = new Set(['cape_top','cape_mid','cape_bottom']);
const HIDDEN_DETAILS = new Set([
 'arnes_frontal','collar_dentado','yugo','espina_0','espina_1','espina_2',
 'mano_hombro_R','dedo_hR_0','dedo_hR_1','dedo_hR_2','dedo_hR_3','dedo_hR_4',
 'mano_hombro_L','dedo_hL_0','dedo_hL_1','dedo_hL_2','dedo_hL_3','dedo_hL_4',
 'cristal_top_L','flujo_violeta_0','esquirla_0','esquirla_1','nucleo_sigilo',
 'mano_sigilo','dedo_sigilo_0','dedo_sigilo_1','dedo_sigilo_2','dedo_sigilo_3',
 'dedo_sigilo_4','cinturon_oxidado','lengueta','colgajo_R','colgajo_L',
 'cristal_mid_R','cristal_mid_L','flujo_violeta_1','flujo_violeta_2',
 'esquirla_2','esquirla_3','jiron_0','jiron_1','jiron_2','jiron_3','jiron_4',
 'faldon_R','faldon_R_tip','faldon_L','faldon_L_tip','cristal_bot_R',
 'flujo_violeta_3','flujo_violeta_4','esquirla_4','esquirla_5','esquirla_6',
 'esquirla_7','hombrera_der','tira_der_0','tira_der_1','hombrera_izq',
 'tira_izq_0','tira_izq_1']);

function runtimeHidden(geo) {
  const parent = {}, h = new Set();
  for (const b of geo.bones) { parent[b.name] = b.parent; if (SECTION_BONES.has(b.name) || HIDDEN_DETAILS.has(b.name)) h.add(b.name); }
  for (const b of geo.bones) {
    let cur = parent[b.name];
    while (cur) { if (HIDDEN_DETAILS.has(cur)) { h.add(b.name); break; } cur = parent[cur]; }
  }
  return h;
}

/* ---------- animación (réplica de CapaArmorModel + posed) ---------- */
function animate(geo, t, speed) {
  const out = geo.bones.map(b => ({ ...b, rotation: (b.rotation || [0,0,0]).slice() }));
  const secs = { cape_top: 0, cape_mid: 1, cape_bottom: 2 };
  for (const b of out) {
    const n = b.name;
    if (n.startsWith('v15_cloth_')) {
      const tail = n.slice(10), si = secs[tail.slice(0, tail.lastIndexOf('_'))];
      const col = parseInt(tail.slice(tail.lastIndexOf('_') + 1), 10);
      const share = 0.30 + 0.35 * si;
      const wave = Math.sin(t * (4.4 + speed * 2.2) - si * 0.55 - col * 0.030);
      const ripple = Math.sin(t * 2.3 - si * 0.7 + col * 0.42);
      const lateral = (col - 4) / 4;
      b.rotation[0] -= (0.55 + speed) * 6.0 * share * (0.55 + 0.45 * wave);
      b.rotation[1] += ripple * 0.9 * share * (0.30 + 0.70 * Math.abs(lateral));
      b.rotation[2] += (lateral * 2.1 + ripple * 0.85) * 0.45 * share;
    } else if (n.startsWith('v15_hem_')) {
      const col = parseInt(n.slice(n.lastIndexOf('_') + 1), 10);
      b.rotation[2] += Math.sin(t * 5.1 - col * 0.55) * (1.2 + speed * 2.0);
    } else if (n.startsWith('v15_rear_pad_')) {
      const i = n.endsWith('L') ? 0 : 1;
      b.rotation[0] += Math.sin(t * 2.6 + i * 1.7) * (1.0 + speed * 2.0);
      b.rotation[2] += Math.sin(t * 1.8 + i * 1.2) * 0.8;
    } else if (n.startsWith('v15_orbit_')) {
      const i = parseInt(n.slice(n.lastIndexOf('_') + 1), 10);
      b.rotation[2] += Math.sin(t * 0.85 + i * Math.PI / 2) * 2.0;
    } else if (n.startsWith('v15_pauldron_') || n.startsWith('v15_front_chain_')) {
      b.rotation[2] += Math.sin(t * 2.1 + n.length * 0.3) * 1.4;
    } else if (n.startsWith('v16_mote_') || n.startsWith('v16_ash_')) {
      // Pivote desplazado: girar el hueso DESPLAZA la partícula de verdad.
      const i = parseInt(n.slice(n.lastIndexOf('_') + 1), 10) || 0;
      const ph = t * 2.4 + i * 0.37;
      const amp = 7 + speed * 9;
      b.rotation[0] += Math.sin(ph * 1.7) * amp;
      b.rotation[1] += Math.cos(ph * 0.9 + i) * amp * 0.7;
      b.rotation[2] += Math.sin(ph) * amp * 0.5;
    } else if (n.startsWith('v16_collar_') || n.startsWith('v16_yoke_')) {
      const i = parseInt(n.slice(n.lastIndexOf('_') + 1), 10) || 0;
      b.rotation[0] += Math.sin(t * 1.9 + i * 0.37) * (1.2 + speed);
      b.rotation[2] += Math.sin(t * 1.1 + i) * 0.7;
    } else if (n.startsWith('v16_vein_')) {
      const i = parseInt(n.slice(n.lastIndexOf('_') + 1), 10) || 0;
      b.rotation[2] += Math.sin(t * 6.2 + i) * (1.4 + speed * 1.6);
    } else if (n.startsWith('v16_tatter_') || n.startsWith('v16_shred_') ||
               n.startsWith('v16_fray_') || n.startsWith('v16_hem_')) {
      const i = parseInt(n.slice(n.lastIndexOf('_') + 1), 10) || 0;
      const seg = (i % 5) / 5;
      const ph = t * (2.4 + speed * 1.4) - seg * 1.8 + i * 0.11;
      b.rotation[0] += (2.0 + 4.0 * seg) * (0.4 + 0.6 * Math.sin(ph));
      b.rotation[1] += Math.sin(ph * 0.7 + i) * (1.4 + speed * 2.2);
      b.rotation[2] += Math.sin(ph * 0.6 + i) * 2.6;
    }
  }
  return { ...geo, bones: out };
}

function matrices(geo) {
  const by = {}, out = {};
  for (const b of geo.bones) by[b.name] = b;
  function calc(n) {
    if (out[n]) return out[n];
    const b = by[n], p = b.pivot || [0,0,0], B = [-p[0], p[1], p[2]];
    const local = mul(mul(T(B), rotmat(b.rotation || [0,0,0])), T([-B[0],-B[1],-B[2]]));
    const P = b.parent ? calc(b.parent) : ident();
    out[n] = mul(P, local);
    return out[n];
  }
  for (const n in by) calc(n);
  return out;
}

const CORNERS = [[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
const FACE_ORDER = {
  west:[7,3,0,4], east:[2,6,5,1], north:[3,2,1,0],
  south:[6,7,4,5], up:[7,6,2,3], down:[0,1,5,4]
};
function faceUV(s) {
  const u=s.uv[0], v=s.uv[1], w=s.uv_size[0], h=s.uv_size[1];
  return [[u+w,v],[u,v],[u,v+h],[u+w,v+h]];
}

function layerFilter(name, layers) {
  if (!layers.cloth && (name.startsWith('v15_cloth_') || name.startsWith('v15_orbit_'))) return true;
  if (!layers.collar && (name.startsWith('v16_collar_') || name.startsWith('v16_fray_') ||
      name.startsWith('v16_yoke_') || name.startsWith('v15_rear_pad_'))) return true;
  if (!layers.shreds && (name.startsWith('v16_tatter_') || name.startsWith('v16_shred_') ||
      name.startsWith('v15_hem_'))) return true;
  if (!layers.particles && (name.startsWith('v16_mote_') || name.startsWith('v16_ash_'))) return true;
  if (!layers.energy && name.startsWith('v16_vein_')) return true;
  return false;
}

function playerFaces() {
  // Maniquí Steve/Alex a escala (1 bloque = 16 unidades). NO está en el
  // .geo.json: existe aquí y en el .bbmodel para juzgar el ajuste al cuello.
  const parts = [
    [-4, 24, -4, 8, 8, 8, [216, 214, 222]],
    [-4, 12, -2, 8, 12, 4, [58, 42, 76]],
    [-8, 12, -2, 4, 12, 4, [88, 62, 112]],
    [ 4, 12, -2, 4, 12, 4, [88, 62, 112]],
    [-4,  0, -2, 4, 12, 4, [42, 30, 56]],
    [ 0,  0, -2, 4, 12, 4, [42, 30, 56]],
  ];
  const out = [];
  for (const [x, y, z, w, h, d, color] of parts) {
    const V = CORNERS.map(k => [x + k[0]*w, y + k[1]*h, z + k[2]*d]);
    for (const fn in FACE_ORDER) {
      const idx = FACE_ORDER[fn];
      out.push({ pts: idx.map(i => V[i]), uvs: [[0,0],[0,0],[0,0],[0,0]], color });
    }
  }
  return out;
}

function collect(geo, hidden, layers) {
  const mats = matrices(geo), faces = [];
  for (const b of geo.bones) {
    if (hidden.has(b.name) || layerFilter(b.name, layers)) continue;
    const M = mats[b.name];
    for (const c of (b.cubes || [])) {
      const o=c.origin, sz=c.size;
      const O = [-(o[0]+sz[0]), o[1], o[2]];
      const V = CORNERS.map(k => [O[0]+k[0]*sz[0], O[1]+k[1]*sz[1], O[2]+k[2]*sz[2]]);
      const VT = V.map(v => apply(M, v));
      for (const fn in FACE_ORDER) {
        const spec = c.uv && c.uv[fn];
        if (!spec) continue;
        const idx = FACE_ORDER[fn];
        faces.push({ pts: idx.map(i => VT[i]), uvs: faceUV(spec) });
      }
    }
  }
  return faces;
}

/* ---------- rasterizador con z-buffer ---------- */
let lastScale = null;
function render(faces, yaw, pitch, zoom, size) {
  const view = mul(R('x', pitch), R('y', yaw));
  const prepared = [];
  let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
  const LIGHT = [-0.35, 0.65, 0.68];
  const ln = Math.hypot(...LIGHT);
  for (let i=0;i<3;i++) LIGHT[i] /= ln;
  for (const f of faces) {
    const pv = f.pts.map(p => apply(view, p));
    const e1=[pv[1][0]-pv[0][0],pv[1][1]-pv[0][1],pv[1][2]-pv[0][2]];
    const e2=[pv[2][0]-pv[0][0],pv[2][1]-pv[0][1],pv[2][2]-pv[0][2]];
    const n=[e1[1]*e2[2]-e1[2]*e2[1], e1[2]*e2[0]-e1[0]*e2[2], e1[0]*e2[1]-e1[1]*e2[0]];
    const l=Math.hypot(...n);
    let shade=0.45;
    if (l>1e-6) shade = 0.40 + 0.60*Math.abs((n[0]*LIGHT[0]+n[1]*LIGHT[1]+n[2]*LIGHT[2])/l);
    for (const p of pv) { x0=Math.min(x0,p[0]); x1=Math.max(x1,p[0]); y0=Math.min(y0,p[1]); y1=Math.max(y1,p[1]); }
    prepared.push({pv, uvs:f.uvs, shade, color:f.color || null});
  }
  const cx=(x0+x1)/2, cy=(y0+y1)/2;
  const base = Math.min((size-46)/(x1-x0||1), (size-46)/(y1-y0||1));
  const scale = base * zoom;
  lastScale = scale;

  const img = ctx.createImageData(size, size);
  const pix = img.data;
  const BG=[18,14,26];
  for (let i=0;i<size*size;i++) { pix[i*4]=BG[0]; pix[i*4+1]=BG[1]; pix[i*4+2]=BG[2]; pix[i*4+3]=255; }
  const depth = new Float32Array(size*size).fill(-1e9);
  const A = ATLAS, AW=ATLAS_W, AH=ATLAS_H;

  for (const q of prepared) {
    const scr = q.pv.map(p => [size/2+(p[0]-cx)*scale, size/2-(p[1]-cy)*scale]);
    const z = q.pv.map(p => p[2]);
    const U = q.uvs;
    for (const [i,j,k] of [[0,1,2],[0,2,3]]) {
      const p0=scr[i], p1=scr[j], p2=scr[k];
      const m00=p1[0]-p0[0], m01=p2[0]-p0[0], m10=p1[1]-p0[1], m11=p2[1]-p0[1];
      const det=m00*m11-m01*m10;
      if (Math.abs(det)<1e-6) continue;
      const i00=m11/det, i01=-m01/det, i10=-m10/det, i11=m00/det;
      const bx0=Math.max(0,Math.floor(Math.min(p0[0],p1[0],p2[0])));
      const bx1=Math.min(size,Math.ceil(Math.max(p0[0],p1[0],p2[0]))+1);
      const by0=Math.max(0,Math.floor(Math.min(p0[1],p1[1],p2[1])));
      const by1=Math.min(size,Math.ceil(Math.max(p0[1],p1[1],p2[1]))+1);
      if (bx1<=bx0||by1<=by0) continue;
      for (let yy=by0; yy<by1; yy++) {
        const dy=yy-p0[1];
        for (let xx=bx0; xx<bx1; xx++) {
          const dx=xx-p0[0];
          const a=i00*dx+i01*dy, b=i10*dx+i11*dy;
          if (a<-1e-6||b<-1e-6||a+b>1+1e-6) continue;
          const zz=z[i]+a*(z[j]-z[i])+b*(z[k]-z[i]);
          const idx=yy*size+xx;
          if (zz<=depth[idx]) continue;
          const uu=U[i][0]+a*(U[j][0]-U[i][0])+b*(U[k][0]-U[i][0]);
          const vv=U[i][1]+a*(U[j][1]-U[i][1])+b*(U[k][1]-U[i][1]);
          let ui=Math.round(uu), vi=Math.round(vv);
          if (ui<0) ui=0; else if (ui>=AW) ui=AW-1;
          if (vi<0) vi=0; else if (vi>=AH) vi=AH-1;
          const ti=(vi*AW+ui)*4, di=idx*4;
          const solid=q.color;
          const al=solid ? 1 : A[ti+3]/255;
          if (al<=0.03) continue;
          const cr=solid ? solid[0] : A[ti];
          const cg=solid ? solid[1] : A[ti+1];
          const cb=solid ? solid[2] : A[ti+2];
          const s=q.shade;
          pix[di]  = pix[di]*(1-al) + cr*s*al;
          pix[di+1]= pix[di+1]*(1-al) + cg*s*al;
          pix[di+2]= pix[di+2]*(1-al) + cb*s*al;
          depth[idx]=zz;
        }
      }
    }
  }
  ctx.putImageData(img,0,0);
}

/* ---------- estado / UI ---------- */
let yaw=0, pitch=8, zoom=1.0, playing=true, t=0, speed=0.35;
let lastFrame=0, dirty=true;
const layers = { cloth:true, collar:true, shreds:true, particles:true, energy:true };
let showPlayer = true;
let hidden = null;

function draw(now) {
  requestAnimationFrame(draw);
  if (!GEO || !ATLAS) return;
  if (playing) { t += Math.min(0.05,(now-lastFrame)/1000) * (0.6+speed*1.4); dirty=true; }
  lastFrame=now;
  if (!dirty) return;
  const g = animate(GEO, t, speed);
  const faces = collect(g, hidden, layers);
  if (showPlayer) faces.push(...playerFaces());
  render(faces, yaw, pitch, zoom, SIZE);
  document.getElementById('faces').textContent = faces.length;
  dirty=false;
}

async function boot() {
  const geo = await (await fetch(GEO_URL)).json();
  GEO = geo['minecraft:geometry'][0];
  hidden = runtimeHidden(GEO);
  const im = new Image();
  im.src = ATLAS_URL;
  await new Promise(r => im.onload = r);
  const off = document.createElement('canvas'); off.width=im.width; off.height=im.height;
  const octx = off.getContext('2d'); octx.drawImage(im,0,0);
  const d = octx.getImageData(0,0,im.width,im.height);
  ATLAS = new Uint8ClampedArray(d.data); ATLAS_W=im.width; ATLAS_H=im.height;
  document.getElementById('loading').style.display='none';
  document.getElementById('bones').textContent = GEO.bones.length;
  requestAnimationFrame(draw);
  drawIcons();
}

/* ---------- iconos animados ---------- */
const ICON_MAP = {
  fiel: null, blight: null
};
let PAL = {
 '.':[0,0,0,0], K:[12,5,18,255], H:[42,11,28,255], D:[66,24,70,255],
 M:[88,30,84,255], L:[112,52,108,255], G:[232,104,172,255],
 W:[255,222,238,255], C:[214,34,138,255], E:[96,22,72,255], P:[140,20,96,255]
};
async function loadIconRows() {
  // Se leen del pipeline para que el visor muestre EXACTAMENTE lo que hay en el código.
  const txt = await (await fetch('assets/icon_src.txt')).text();
  const m = txt.match(/ICON_ALTERNATIVE = \(([\s\S]*?)\n\)/);
  const n = txt.match(/ICON_PIXEL_MAP = \(([\s\S]*?)\n\)/);
  const grab = s => (s.match(/"([.A-Z]{16})"/g) || []).map(x => x.slice(1,-1));
  ICON_MAP.fiel = grab(m[1]);
  ICON_MAP.blight = grab(n[1]);
  const pm = txt.match(/ICON_PALETTE = \{([\s\S]*?)\n\}/);
  if (pm) {
    const out = {'.':[0,0,0,0]};
    for (const hit of pm[1].matchAll(/"([A-Z.])":\s*\((\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)/g)) {
      out[hit[1]] = [+hit[2], +hit[3], +hit[4], +hit[5]];
    }
    PAL = out;
  }
}
let iconChoice='blight', iconFrame=0;
function iconTick() {
  requestAnimationFrame(iconTick);
  if (!ICON_MAP.blight || !ICON_MAP.fiel) return;
  iconFrame += 1;
  if (iconFrame % 4 !== 0) return;
  const phase = Math.sin(performance.now()/520);
  for (const id of ['iconA','iconB']) {
    const cv=document.getElementById(id); if(!cv) continue;
    const which = id==='iconA' ? iconChoice : (iconChoice==='blight'?'fiel':'blight');
    const rows=ICON_MAP[which]; if(!rows || rows.length!==16) continue;
    const c=cv.getContext('2d'), S=14;
    c.clearRect(0,0,cv.width,cv.height);
    c.fillStyle='#120e1a'; c.fillRect(0,0,cv.width,cv.height);
    for (let y=0;y<16;y++) for (let x=0;x<16;x++) {
      let ch=rows[y][x];
      // animación: la estrella y el broche pulsan; el festón ondea 1 px
      if (ch==='C' && phase>0.35) ch='W';
      if (ch==='G' && phase>0.80) ch='W';
      let dy=0;
      if (y===15 && ch!=='.') dy = phase>0.4 ? -1 : 0;
      const col=PAL[ch]; if(!col || col[3]===0) continue;
      c.fillStyle=`rgba(${col[0]},${col[1]},${col[2]},${col[3]/255})`;
      c.fillRect(x*S,(y+dy)*S,S,S);
    }
  }
}
async function drawIcons() { await loadIconRows(); requestAnimationFrame(iconTick); }

/* ---------- interacción ---------- */
let dragging=false, lx=0, ly=0;
canvas.addEventListener('pointerdown', e => { dragging=true; lx=e.clientX; ly=e.clientY; canvas.setPointerCapture(e.pointerId); });
canvas.addEventListener('pointerup', () => dragging=false);
canvas.addEventListener('pointermove', e => {
  if (!dragging) return;
  yaw += (e.clientX-lx)*0.55; pitch = Math.max(-70,Math.min(70,pitch+(e.clientY-ly)*0.4));
  lx=e.clientX; ly=e.clientY; dirty=true;
});
canvas.addEventListener('wheel', e => {
  e.preventDefault(); zoom=Math.max(0.55,Math.min(2.4,zoom*(e.deltaY>0?0.92:1.08))); dirty=true;
}, {passive:false});

function setView(y,p) { yaw=y; pitch=p; dirty=true; }
document.getElementById('vFront').onclick = ()=>setView(180,8);
document.getElementById('vBack').onclick  = ()=>setView(0,8);
document.getElementById('vSide').onclick  = ()=>setView(-62,14);
document.getElementById('v34').onclick    = ()=>setView(25,14);
document.getElementById('vTop').onclick   = ()=>setView(0,52);
document.getElementById('play').onclick = e => {
  playing=!playing; e.target.textContent = playing?'⏸ Pausar animación':'▶ Reproducir animación'; dirty=true;
};
document.getElementById('speed').oninput = e => { speed=parseFloat(e.target.value); document.getElementById('speedVal').textContent=speed.toFixed(2); };
document.getElementById('res').onchange = e => {
  SIZE=parseInt(e.target.value,10); canvas.width=SIZE; canvas.height=SIZE; dirty=true;
};
for (const k of Object.keys(layers)) {
  const el=document.getElementById('l_'+k);
  if (el) el.onchange = () => { layers[k]=el.checked; dirty=true; };
}
const pEl=document.getElementById('l_player');
if (pEl) pEl.onchange = () => { showPlayer=pEl.checked; dirty=true; };
document.getElementById('choice').onchange = e => { iconChoice=e.target.value; };

boot().catch(e => { document.getElementById('loading').textContent='Error: '+e.message; });
