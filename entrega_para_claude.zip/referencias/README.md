# Referencias incluidas

| Archivo | Qué es | Cómo usarlo |
|---|---|---|
| `01_OBJETIVO_blockbench.png` | **LA REFERENCIA DEL USUARIO.** Captura de Blockbench (1024×572) con el maniquí de cabeza blanca y la capa deshilachada. | Es el objetivo de volumen, silueta y color. Mirarla primero. |
| `01b_OBJETIVO_detalle.png` | Recorte ampliado (750×780) de la misma captura. | Para ver la textura: rojo oscuro arriba → violeta → negro, vetas rosa en trazos cortos, agujeros negros, puntas desiguales. |
| `02_RECHAZADO_v1140_visor.png` | Render del visor de la **v1.14.0**, rechazado: «Que es esto amigo…». | Jaula de tiras finas magenta + cubo blanco. NO repetir. |
| `03_RECHAZADO_v1150_6vistas.png` | Comparativa de 6 vistas de la **v1.15.0**, también rechazada: «la skin de la capa la haces muy mal». | Sigue pareciendo una rejilla de barras con brillo; masa de tela insuficiente. NO repetir. |
| `04a_INGAME_espalda_viejo.png`, `04b_INGAME_frente_viejo.png`, `04c_INGAME_espalda_viejo.png` | Capturas in-game de versiones anteriores (v1.9–v1.12 aprox.). | Sólo para entender **escala sobre el jugador** y cómo cuelga la capa en `curios:back`. **No** son objetivo de diseño. |
| `05_ICONO_APROBADO.png` | **Icono 64×64 aprobado por el usuario** («el icono esta bien»). Copia byte-idéntica de `src/main/resources/assets/capatest/textures/item/capa_deteriorer_evilsaiyan.png`. | **INMUTABLE.** SHA-256 `e88ccec0a0c67b1ad0982ed781f0d684ae4662660c545fa134574781967e4840`. Si `texture_pipeline.py` lo regenera, restaurarlo desde aquí. |
| `06_ICONO_ANTERIOR_blight_NO_USAR.png` | Icono `blight` de v1.13.0, también aprobado en su momento pero **ya reemplazado**. | Contexto histórico. No usar. |
| `07_CANVAS_ACTUAL_96x48.png` | Canvas continuo de la capa (recorte 0,0–96,48 del atlas) ampliado 6× con NEAREST. | Muestra exactamente qué se está pintando hoy y por qué queda mal. |
| `08_ATLAS_ACTUAL_128x128.png` | Atlas completo de armadura ampliado 4×. | Para ver las zonas reservadas / UV (`tools/cloth_spec.py`). |
| `09_GLOWMASK_ACTUAL.png` | Glowmask de armadura ampliado 4×. | 1636 texels emisivos: no se deben perder ni ensuciar. |

## Lectura rápida del objetivo

La referencia muestra una **bufanda gruesa carmesí** que envuelve cuello y
hombros con el borde inferior rasgado; de ella bajan **jirones anchos y
solapados** que se estrechan en puntas desiguales. El color va de rojo oscuro
a violeta y casi negro hacia abajo, con gris ceniza, suciedad y **huecos
negros reales**. La energía rosa aparece en **trazos cortos y discontinuos**,
no en líneas continuas ni en una red. Hay unas pocas motas de 1–2 px
flotando, más densas abajo. La cabeza blanca es **sólo el maniquí de
referencia**, no parte de la capa.

Lo que hay que evitar: tiras finas todas iguales, rejilla, neón magenta por
toda la superficie, franjas regulares, cubos planos, puntas simétricas,
silueta rectangular y añadir más brillo/partículas como "arreglo".
