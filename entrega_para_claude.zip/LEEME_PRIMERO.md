# Entrega para Claude — capa "Mantle of the Blight Star"

**Pedido del usuario:** «dame un zip con el proyecto y un prompt, lo hare con
claude... el icono esta bien». La skin de la capa equipada fue rechazada dos
veces; el icono 64×64 está **aprobado y es inmutable**.

## Orden de lectura

1. `PROMPT.txt` — **copiar y pegar** en Claude (texto plano, sin Markdown).
   `PROMPT.md` es el mismo prompt con anexos.
2. `referencias/README.md` y las imágenes, sobre todo
   `01_OBJETIVO_blockbench.png` + `01b_OBJETIVO_detalle.png` (objetivo) y
   `02_*` / `03_*` (lo que NO hay que repetir).
3. `ESTADO_TECNICO.md` — mapa del repo, invariantes del CI, historial y
   errores ya cometidos.
4. `proyecto/` — código y assets. No incluye `.git/` ni `tools/_deps/`.

## Recordatorios

- El icono: `proyecto/src/main/resources/assets/capatest/textures/item/capa_deteriorer_evilsaiyan.png`,
  copia exacta en `referencias/05_ICONO_APROBADO.png`, SHA-256 en
  `CHECKSUMS.sha256`. `tools/texture_pipeline.py` lo regenera al ejecutarlo.
- No hay `gradle`/`java` en el sandbox original: el build Java lo hace GitHub
  Actions. Dependencias Python: `pip install --target tools/_deps Pillow numpy PyYAML`.
- **No publicar ni hacer commit/push/Release sin aprobación visual del usuario.**
