#!/usr/bin/env python3
"""Genera la reliquia holografica (bbmodel + geo + animaciones + texturas + preview)."""
import json, math, random, uuid, base64, zlib, struct, os, io, itertools

random.seed(20261112)
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
for d in ['source', 'export/geo', 'export/animations', 'textures', 'preview']:
    os.makedirs(f'{BASE}/{d}', exist_ok=True)

C = (-6.0, 30.0, 8.0)   # centro del nucleo: sobre un hombro, detras del jugador (Z+ = espalda)
TEX = 64
K = 0.55   # escala global del modelo (v3: mas pequeno)


def U():
    return str(uuid.UUID(int=random.getrandbits(128), version=4))


# ---------------------------------------------------------------- textura
PAL = [(234, 251, 255, 255), (189, 244, 255, 255), (25, 240, 255, 255), (70, 190, 255, 255),
       (10, 155, 255, 255), (11, 91, 216, 255), (6, 42, 110, 255), (3, 22, 66, 255),
       (189, 244, 255, 215), (25, 240, 255, 195), (10, 155, 255, 175), (11, 91, 216, 150),
       (95, 247, 255, 150), (42, 174, 255, 150), (70, 190, 255, 170), (255, 255, 255, 255),
       (60, 170, 255, 60), (140, 230, 255, 45)]
# swatch i -> celda 8x8 en rejilla 8x8; cada celda son 16 bloques de 2x2 con ligera variacion
pix = [[(0, 0, 0, 0)] * TEX for _ in range(TEX)]
for i, (r, g, b, a) in enumerate(PAL):
    cx, cy = (i % 8) * 8, (i // 8) * 8
    for bj in range(4):
        for bi in range(4):
            k = random.uniform(0.88, 1.08)
            col = (min(255, int(r * k)), min(255, int(g * k)), min(255, int(b * k)), a)
            for dy in range(2):
                for dx in range(2):
                    pix[cy + bj * 2 + dy][cx + bi * 2 + dx] = col


def png_bytes(p):
    raw = b''.join(b'\x00' + bytes(c for px in row for c in px) for row in p)
    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', TEX, TEX, 8, 6, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))


PNG = png_bytes(pix)
open(f'{BASE}/textures/relic_hologram.png', 'wb').write(PNG)
open(f'{BASE}/textures/relic_hologram_glowing.png', 'wb').write(PNG)


def swatch_uv(sw):
    bi, bj = random.randrange(4), random.randrange(4)
    u, v = (sw % 8) * 8 + bi * 2, (sw // 8) * 8 + bj * 2
    return u, v


# ---------------------------------------------------------------- geometria
class G:
    def __init__(s, name, origin, rot=(0, 0, 0), parent=None):
        s.name, s.origin, s.rot, s.uuid, s.parent = name, origin, rot, U(), parent
        s.children, s.cubes = [], []
        GROUPS.append(s)
        if parent:
            parent.children.append(s)


GROUPS, ELEMS = [], []


def add(c, name, center, size, sw):
    sx, sy, sz = size[0] * K, size[1] * K, size[2] * K
    fr = [center[0] - sx / 2, center[1] - sy / 2, center[2] - sz / 2]
    to = [center[0] + sx / 2, center[1] + sy / 2, center[2] + sz / 2]
    u, v = swatch_uv(sw)
    e = dict(name=name, fr=[round(x, 4) for x in fr], to=[round(x, 4) for x in to],
             origin=[round(x, 4) for x in center], uv=(u, v), uuid=U(), group=c)
    ELEMS.append(e)
    c.cubes.append(e)


def rel(p):
    return (C[0] + K * p[0], C[1] + K * p[1], C[2] + K * p[2])


root = G('relic_root', C)

# --- nucleo
core = G('core', C, parent=root)
inner = G('core_inner', C, parent=core)
mid = G('core_mid', C, parent=core)
shell = G('core_shell', C, parent=core)
debris = G('core_debris', C, parent=core)
n_deb = 0
for ix, iy, iz in itertools.product(range(-4, 5), repeat=3):
    d = math.sqrt(ix * ix + iy * iy + iz * iz)
    pos = rel((ix, iy, iz))
    if d <= 1.6:
        add(inner, f'core_in_{ix}_{iy}_{iz}', pos, (1, 1, 1), 0 if d < 0.5 else 1)
    elif d <= 2.4:
        add(mid, f'core_mid_{ix}_{iy}_{iz}', pos, (1, 1, 1), 3 if random.random() < .25 else 2)
    elif d <= 3.1:
        if random.random() < 0.82:
            add(shell, f'core_sh_{ix}_{iy}_{iz}', pos, (.96, .96, .96),
                4 if random.random() < .2 else random.choice([12, 13]))
    elif d <= 4.0 and random.random() < 0.07 and n_deb < 8:
        n_deb += 1
        add(debris, f'core_deb_{n_deb}', pos, (.7, .7, .7), random.choice([12, 13, 14]))


for k in range(16):
    v = [random.gauss(0, 1) for _ in range(3)]
    l = math.sqrt(sum(x * x for x in v)) or 1
    rr = random.uniform(3.4, 5.2); sz = random.choice([.4, .5, .6])
    add(debris, f'core_spark_{k}', rel([x / l * rr for x in v]), (sz, sz, sz), random.choice([1, 2, 12, 13]))

aura = G('core_aura', C, parent=core)
for ix, iy, iz in itertools.product(range(-3, 4), repeat=3):
    d = math.sqrt(ix * ix + iy * iy + iz * iz) * 1.5
    if 3.2 <= d <= 4.4 and random.random() < .55:
        add(aura, f'aura_{ix}_{iy}_{iz}', rel((ix * 1.5, iy * 1.5, iz * 1.5)), (1.5, 1.5, 1.5), random.choice([16, 17]))

# --- anillos (pixel-rings sin rotaciones de cubo: todo alineado a ejes)
def build_ring(spin, tag, r, step, gaps, nodes, thick=.5, sw_fn=None):
    n = int(r / step) + 2
    cells = []
    for i in range(-n, n + 1):
        for j in range(-n, n + 1):
            x, z = i * step, j * step
            if abs(math.hypot(x, z) - r) <= step * .5:
                t = (math.atan2(z, x) / (2 * math.pi)) % 1
                if any(a <= t < b for a, b in gaps):
                    continue
                cells.append((x, z, t))
    node_cells = set()
    for k in range(nodes):
        tt = (k / nodes + .02) % 1
        best = min(range(len(cells)), key=lambda q: min(abs(cells[q][2] - tt), 1 - abs(cells[q][2] - tt)))
        node_cells.add(best)
    for q, (x, z, t) in enumerate(cells):
        if q in node_cells:
            add(spin, f'{tag}_node_{q}', rel((x, 0, z)), (1, 1, 1), 1)
        else:
            sw = sw_fn(t)
            add(spin, f'{tag}_seg_{q}', rel((x, 0, z)), (step, thick, step), sw)


def trail(t):
    return 8 if t < .10 else 9 if t < .45 else 10 if t < .75 else 11


def build_trail(spin, tag, a, b, phase, span, wmax, wob, step=.5, thick=.5):
    """Estela eliptica en espiral con cola afilada (cola = t->1), todo alineado a ejes."""
    cells = {}
    N = 1000
    for q in range(N + 1):
        t = q / N
        th = phase + span * t
        rr = 1 + .06 * t
        x, z, y = a * rr * math.cos(th), b * rr * math.sin(th), wob * math.sin(2 * th + phase)
        dx, dz = -a * math.sin(th), b * math.cos(th)
        l = math.hypot(dx, dz); nx, nz = dz / l, -dx / l
        w = wmax * (1 - t) ** 1.1 + .12
        k = int(w / step) + 1
        for o in range(-k, k + 1):
            off = o * step
            if abs(off) > w:
                continue
            key = (round((x + nx * off) / step), round(y / thick), round((z + nz * off) / step))
            if key not in cells or cells[key] > t:
                cells[key] = t
    for n_, ((ix, iy, iz), t) in enumerate(cells.items()):
        pos = rel((ix * step, iy * thick, iz * step))
        if t < .05:
            add(spin, f'{tag}_head_{n_}', pos, (step, thick * 1.6, step), 1)
        else:
            sw = 8 if t < .12 else 9 if t < .35 else 10 if t < .65 else 11
            add(spin, f'{tag}_seg_{n_}', pos, (step * .96, thick, step * .96), sw)


TRAILS = [(9.2, 5.4, 0.0, 1.5 * math.pi, .6, 0, (14, 0, 22)),
          (8.0, 4.8, 2.1, 1.5 * math.pi, .55, 0, (22, 0, 16)),
          (7.0, 5.2, 4.2, 1.45 * math.pi, .5, 0, (-10, 0, 26)),
          (10.5, 3.9, 1.2, 1.2 * math.pi, .3, 0, (-32, 0, 34))]
for i, (a_, b_, ph, span, w_, wob, tilt) in enumerate(TRAILS, 1):
    tg = G(f'ring_tilt_{i}', C, tilt, root)
    sg = G(f'ring_spin_{i}', C, parent=tg)
    build_trail(sg, f'trail{i}', a_, b_, ph, span, w_, wob)
for j, (r_, gp, nd) in enumerate([(4.3, [], 4), (5.4, [(.55, .62)], 2)], 5):
    tg = G(f'ring_tilt_{j}', C, (14, 0, 22), root)
    sg = G(f'ring_spin_{j}', C, parent=tg)
    build_ring(sg, f'ring{j}', r_, .5, gp, nd, thick=.3, sw_fn=trail)

# --- orbitas de fragmentos
def orbit(tag, tilt, n, rmin, rmax):
    tg = G(f'frag_tilt_{tag}', C, tilt, root)
    og = G(f'frag_orbit_{tag}', C, parent=tg)
    for k in range(n):
        a = 2 * math.pi * (k + random.uniform(-.3, .3)) / n
        rr = random.uniform(rmin, rmax)
        y = random.uniform(-.9, .9)
        s = random.choice([.6, .8, 1.0, 1.2])
        add(og, f'frag_{tag}_{k}', rel((rr * math.cos(a), y, rr * math.sin(a))), (s, s, s),
            random.choice([2, 3, 4, 5, 12, 13]))


orbit('a', (25, 0, -20), 7, 5.0, 7.4)
orbit('b', (-40, 0, 55), 5, 5.4, 7.8)

# --- fragmentos que derivan / aparecen y desaparecen
NDRIFT = 8
DRIFT = []
for i in range(NDRIFT):
    while True:
        v = [random.gauss(0, 1) for _ in range(3)]
        l = math.sqrt(sum(x * x for x in v))
        if l > .1:
            break
    u = [x / l for x in v]
    r = random.uniform(4.4, 6.8)
    h = [u[0] * r, u[1] * r, u[2] * r]
    s = random.choice([.6, .7, .8, 1.0])
    c = rel(h)
    g = G(f'drift_{i + 1:02d}', c, parent=root)
    add(g, f'drift_cube_{i + 1:02d}', c, (s, s, s), random.choice([2, 3, 4, 12, 13, 14]))
    DRIFT.append((g.name, h, u))

# --- efectos de onda y destello (escala 0 en reposo, ver animaciones)
shock = G('shock_ring', C, parent=root)
build_ring(shock, 'shock', 3.0, .8, [], 0, thick=.4, sw_fn=lambda t: 8)
flash = G('flash', C, parent=root)
add(flash, 'flash_x', rel((0, 0, 0)), (8, 1.2, 1.2), 15)
add(flash, 'flash_y', rel((0, 0, 0)), (1.2, 8, 1.2), 15)
add(flash, 'flash_z', rel((0, 0, 0)), (1.2, 1.2, 8), 15)

# ---------------------------------------------------------------- animaciones
FACES = ['north', 'east', 'south', 'west', 'up', 'down']


class Anim:
    def __init__(s, name, length, loop):
        s.name, s.length, s.loop, s.tr = name, length, loop, {}

    def key(s, bone, ch, t, vec, interp='linear'):
        lst = s.tr.setdefault((bone, ch), [])
        lst[:] = [k for k in lst if abs(k[0] - t) > 1e-6]
        lst.append((round(t, 4), [round(float(x), 4) for x in vec], interp))
        lst.sort(key=lambda k: k[0])


def sweep(A, bone, ch, t0, t1, v0, v1, fn, n=8):
    for k in range(n + 1):
        f = k / n
        w = fn(f)
        A.key(bone, ch, t0 + (t1 - t0) * f, [a + (b - a) * w for a, b in zip(v0, v1)])


eo = lambda x: 1 - (1 - x) ** 3
ei = lambda x: x ** 3
eio = lambda x: x * x * (3 - 2 * x)
lin = lambda x: x
Z3, O3 = [0, 0, 0], [1, 1, 1]
S = lambda v: [v, v, v]
TILT = {'ring_tilt_1', 'ring_tilt_2', 'ring_tilt_3', 'frag_tilt_a', 'frag_tilt_b'}
ANIMS = []


def hide_fx(A):
    for b in ('shock_ring', 'flash'):
        if (b, 'scale') not in A.tr:
            A.key(b, 'scale', 0, Z3)


# IDLE ---------------------------------------------------------------
I = Anim('animation.relic.idle', 12, True)
for t, y in zip([0, 3, 6, 9, 12], [0, .9, 0, -.9, 0]):
    I.key('relic_root', 'position', t, [0, y, 0], 'catmullrom')
for t, v in zip([0, 4, 8, 12], [0, 2.5, -2.5, 0]):
    I.key('relic_root', 'rotation', t, [0, 0, v], 'catmullrom')
I.key('core', 'rotation', 0, Z3); I.key('core', 'rotation', 12, [0, 360, 0])
I.key('core_debris', 'rotation', 0, Z3); I.key('core_debris', 'rotation', 12, [0, -720, 0])
for i, k in enumerate([1, -2, 3, -2, -1, 2], 1):
    I.key(f'ring_spin_{i}', 'rotation', 0, Z3); I.key(f'ring_spin_{i}', 'rotation', 12, [0, 360 * k, 0])
I.key('frag_orbit_a', 'rotation', 0, Z3); I.key('frag_orbit_a', 'rotation', 12, [0, -360, 0])
I.key('frag_orbit_b', 'rotation', 0, Z3); I.key('frag_orbit_b', 'rotation', 12, [0, 720, 0])
for t in range(0, 13, 3):
    pass
for bone, hi, lo in (('core_inner', 1.14, 1.0), ('core_mid', 1.07, 1.0)):
    for t in range(0, 13, 3):
        I.key(bone, 'scale', t, S(lo), 'catmullrom')
    for t in (1.5, 4.5, 7.5, 10.5):
        I.key(bone, 'scale', t, S(hi), 'catmullrom')
for t in (0, 3, 6, 9, 12):
    I.key('core_shell', 'scale', t, S(1.0), 'catmullrom')
for t in (1.5, 4.5, 7.5, 10.5):
    I.key('core_shell', 'scale', t, S(.94), 'catmullrom')
rnd = random.Random(5)
for i, (name, h, u) in enumerate(DRIFT):
    vs = [[rnd.uniform(-.8, .8) for _ in range(3)] for _ in range(3)]
    for t, v in zip([0, 3, 6, 9, 12], [Z3] + vs + [Z3]):
        I.key(name, 'position', t, v, 'catmullrom')
    if i % 2:
        a = rnd.uniform(1, 5); b = a + rnd.uniform(1.5, 3)
        for t, v in ((0, 1), (a, 1), (a + .5, 0), (b, 0), (b + .5, 1), (12, 1)):
            I.key(name, 'scale', t, S(v))
hide_fx(I); ANIMS.append(I)

# IDLE DORMANT --------------------------------------------------------
D = Anim('animation.relic.idle_dormant', 6, True)
for t, y in zip([0, 1.5, 3, 4.5, 6], [0, .5, 0, -.5, 0]):
    D.key('relic_root', 'position', t, [0, y, 0], 'catmullrom')
for t, v in zip([0, 1.5, 3, 4.5, 6], [.55, .64, .55, .64, .55]):
    D.key('core_inner', 'scale', t, S(v), 'catmullrom')
D.key('core', 'rotation', 0, Z3); D.key('core', 'rotation', 6, [0, 360, 0])
for b in ['core_mid', 'core_shell', 'core_debris', 'ring_tilt_1', 'ring_tilt_2', 'ring_tilt_3', 'ring_tilt_4', 'ring_tilt_5', 'ring_tilt_6',
          'frag_tilt_a', 'frag_tilt_b'] + [d[0] for d in DRIFT]:
    D.key(b, 'scale', 0, Z3)
hide_fx(D); ANIMS.append(D)

# ENERGY PULSE ---------------------------------------------------------
P = Anim('animation.relic.energy_pulse', 2.4, False)
for bone, pk in (('core_inner', 1.6), ('core_mid', 1.35), ('core_shell', 1.2), ('core_debris', 1.7)):
    P.key(bone, 'scale', 0, S(1)); P.key(bone, 'scale', .22, S(pk))
    sweep(P, bone, 'scale', .22, 2.4, S(pk), S(1), eo)
for i, k in enumerate([1, -2, 2, -1, 1, -1], 1):
    sweep(P, f'ring_spin_{i}', 'rotation', 0, 2.4, Z3, [0, 360 * k, 0], eo)
    P.key(f'ring_tilt_{i}', 'scale', 0, S(1)); P.key(f'ring_tilt_{i}', 'scale', .3, S(1.18))
    sweep(P, f'ring_tilt_{i}', 'scale', .3, 2.4, S(1.18), S(1), eo)
for tag, k in (('a', -1), ('b', 1)):
    sweep(P, f'frag_orbit_{tag}', 'rotation', 0, 2.4, Z3, [0, 360 * k, 0], eio)
    P.key(f'frag_tilt_{tag}', 'scale', 0, S(1)); P.key(f'frag_tilt_{tag}', 'scale', .4, S(1.45))
    sweep(P, f'frag_tilt_{tag}', 'scale', .4, 2.4, S(1.45), S(1), eo)
for name, h, u in DRIFT:
    out = [x * .4 for x in u]
    P.key(name, 'position', 0, Z3); P.key(name, 'position', .4, [x * 1.6 / .4 * .4 for x in u])
    sweep(P, name, 'position', .4, 2.4, [x * 1.6 for x in u], Z3, eo)
P.key('relic_root', 'position', 0, Z3); P.key('relic_root', 'position', .2, [0, .8, 0])
sweep(P, 'relic_root', 'position', .2, 1.4, [0, .8, 0], Z3, eo)
P.key('shock_ring', 'scale', 0, Z3); P.key('shock_ring', 'scale', .12, [.4, 1, .4])
sweep(P, 'shock_ring', 'scale', .12, 1.2, [.4, 1, .4], [2.6, 1, 2.6], eo)
P.key('shock_ring', 'scale', 1.35, Z3)
P.key('flash', 'scale', 0, Z3); P.key('flash', 'scale', .1, S(1.1)); P.key('flash', 'scale', .28, Z3)
ANIMS.append(P)

# ACTIVATION -------------------------------------------------------------
A = Anim('animation.relic.activation', 3.0, False)
A.key('core_inner', 'scale', 0, S(.3)); A.key('core_inner', 'scale', 1.0, S(.9))
A.key('core_inner', 'scale', 1.3, S(1.7)); A.key('core_inner', 'scale', 2.0, S(1.05)); A.key('core_inner', 'scale', 3.0, S(1))
A.key('core_mid', 'scale', 0, S(0)); A.key('core_mid', 'scale', .8, S(.8))
A.key('core_mid', 'scale', 1.3, S(1.4)); A.key('core_mid', 'scale', 2.0, S(1.05)); A.key('core_mid', 'scale', 3.0, S(1))
A.key('core_shell', 'scale', 0, S(0)); A.key('core_shell', 'scale', 1.0, S(.6))
A.key('core_shell', 'scale', 1.35, S(1.3)); A.key('core_shell', 'scale', 2.2, S(1)); A.key('core_shell', 'scale', 3.0, S(1))
A.key('core_debris', 'scale', 0, S(0)); A.key('core_debris', 'scale', 1.3, S(0))
A.key('core_debris', 'scale', 1.5, S(1.8)); A.key('core_debris', 'scale', 2.6, S(1)); A.key('core_debris', 'scale', 3.0, S(1))
for tag, k in (('a', -2), ('b', 3)):
    sweep(A, f'frag_tilt_{tag}', 'scale', 0, 1.9, S(2.4), S(1), eo)
    sweep(A, f'frag_orbit_{tag}', 'rotation', 0, 2.4, Z3, [0, 360 * k, 0], eo)
for i, k in enumerate([1, -2, 2, -1, 1, -1], 1):
    d0 = .4 + .2 * (i - 1)
    A.key(f'ring_tilt_{i}', 'scale', 0, Z3); A.key(f'ring_tilt_{i}', 'scale', d0, Z3)
    A.key(f'ring_tilt_{i}', 'scale', d0 + .9, S(1.3)); A.key(f'ring_tilt_{i}', 'scale', d0 + 1.5, S(1))
    sweep(A, f'ring_spin_{i}', 'rotation', .4, 3.0, Z3, [0, 360 * k, 0], eo)
for i, (name, h, u) in enumerate(DRIFT):
    t0 = .05 * i
    A.key(name, 'scale', 0, Z3); A.key(name, 'scale', t0, Z3); A.key(name, 'scale', t0 + .6, S(1))
    A.key(name, 'position', 0, [x * 4.5 for x in u])
    sweep(A, name, 'position', t0, t0 + 1.5, [x * 4.5 for x in u], Z3, eo)
A.key('flash', 'scale', 0, Z3); A.key('flash', 'scale', 1.2, Z3); A.key('flash', 'scale', 1.3, S(1))
A.key('flash', 'scale', 1.5, S(2.6)); A.key('flash', 'scale', 1.75, Z3)
A.key('shock_ring', 'scale', 0, Z3); A.key('shock_ring', 'scale', 1.3, [.5, 1, .5])
A.key('shock_ring', 'scale', 2.0, [3, 1, 3]); A.key('shock_ring', 'scale', 2.2, Z3)
A.key('relic_root', 'position', 0, Z3); A.key('relic_root', 'position', 1.3, [0, .8, 0]); A.key('relic_root', 'position', 2.4, Z3)
ANIMS.append(A)

# DEACTIVATION ---------------------------------------------------------------
X = Anim('animation.relic.deactivation', 2.2, False)
for i, k in zip([6, 5, 4, 3, 2, 1], [1] * 6):
    s0 = .05 + .1 * (6 - i)
    X.key(f'ring_tilt_{i}', 'scale', 0, S(1))
    sweep(X, f'ring_tilt_{i}', 'scale', s0, s0 + 1.0, S(1), Z3, ei)
    sweep(X, f'ring_spin_{i}', 'rotation', 0, s0 + 1.0, Z3, [0, 360 * (1 if i != 2 else -1), 0], ei)
for tag in 'ab':
    X.key(f'frag_tilt_{tag}', 'scale', 0, S(1))
    sweep(X, f'frag_tilt_{tag}', 'scale', .3, 1.6, S(1), S(.1), ei)
    X.key(f'frag_tilt_{tag}', 'scale', 1.7, Z3)
for i, (name, h, u) in enumerate(DRIFT):
    s0 = .35 + .04 * i
    X.key(name, 'position', 0, Z3)
    sweep(X, name, 'position', s0, s0 + 1.2, Z3, [-x * .98 for x in h], ei)
    X.key(name, 'scale', 0, S(1)); X.key(name, 'scale', s0 + 1.0, S(1)); X.key(name, 'scale', s0 + 1.25, Z3)
X.key('core_shell', 'scale', 0, S(1)); sweep(X, 'core_shell', 'scale', .2, 1.2, S(1), Z3, ei)
X.key('core_mid', 'scale', 0, S(1)); sweep(X, 'core_mid', 'scale', .5, 1.5, S(1), Z3, ei)
X.key('core_debris', 'scale', 0, S(1)); sweep(X, 'core_debris', 'scale', 0, 1.0, S(1), Z3, ei)
X.key('core_inner', 'scale', 0, S(1)); sweep(X, 'core_inner', 'scale', .3, 1.9, S(1), S(.55), eio)
hide_fx(X); ANIMS.append(X)

# GLITCH ----------------------------------------------------------------------
Gl = Anim('animation.relic.glitch', 1.0, False)
for t, v in zip([0, .08, .14, .3, .4, 1.0], [1, 1.25, .85, 1.1, 1, 1]):
    Gl.key('core_shell', 'scale', t, S(v))
for t, v in zip([0, .06, .12, .2, .3, 1.0], [1, .8, 1.2, .9, 1, 1]):
    Gl.key('core_inner', 'scale', t, S(v))
for t, v in zip([0, .06, .12, .18, .24, .3, 1.0], [0, .6, -.5, .3, -.2, 0, 0]):
    Gl.key('relic_root', 'position', t, [v, 0, -v * .5])
for t, v in zip([0, .1, .2, .3, 1.0], [0, 6, -5, 2, 0]):
    Gl.key('relic_root', 'rotation', t, [0, 0, v])
for i, (name, h, u) in enumerate(DRIFT):
    if i % 3 == 0:
        for t, v in ((0, 1), (.08, 1), (.1, 0), (.22, 0), (.24, 1), (1.0, 1)):
            Gl.key(name, 'scale', t, S(v))
hide_fx(Gl); ANIMS.append(Gl)

# ---- extras v3: aura, respiracion de estelas, escala de posiciones
for i in range(1, 7):
    p = 1.5 + .5 * i
    for t, v in ((0, 1), (p, 1.07), (6, 1), (p + 6, 1.07), (12, 1)):
        I.key(f'ring_tilt_{i}', 'scale', t, S(v), 'catmullrom')
for t, v in zip([0, 4, 8, 12], [0, 8, -8, 0]):
    I.key('core_mid', 'rotation', t, [v, 0, 0], 'catmullrom')
for t in (0, 3, 6, 9, 12):
    I.key('core_aura', 'scale', t, S(1), 'catmullrom')
for t in (1.5, 4.5, 7.5, 10.5):
    I.key('core_aura', 'scale', t, S(1.1), 'catmullrom')
D.key('core_aura', 'scale', 0, Z3)
P.key('core_aura', 'scale', 0, S(1)); P.key('core_aura', 'scale', .25, S(1.7))
sweep(P, 'core_aura', 'scale', .25, 2.4, S(1.7), S(1), eo)
for t, v in ((0, 0), (1.2, .5), (1.35, 1.6), (2.4, 1), (3.0, 1)):
    A.key('core_aura', 'scale', t, S(v))
X.key('core_aura', 'scale', 0, S(1)); sweep(X, 'core_aura', 'scale', .1, 1.0, S(1), Z3, ei)
for t, v in ((0, 1), (.1, .6), (.2, 1.3), (.3, 1), (1.0, 1)):
    Gl.key('core_aura', 'scale', t, S(v))
for an in ANIMS:
    for (b, ch), keys in an.tr.items():
        if ch == 'position':
            keys[:] = [(t, [round(x * K, 4) for x in v], ip) for t, v, ip in keys]

# ---------------------------------------------------------------- QC de animaciones
def ang_eq(a, b, ch):
    return abs(a - b) < 1e-3 or (ch == 'rotation' and abs(((a - b) + 180) % 360 - 180) < 1e-3)


bad = []
base = {k: v[0][1] for k, v in I.tr.items()}
for an in ANIMS:
    for (b, ch), keys in an.tr.items():
        if keys[-1][0] > an.length + 1e-6:
            bad.append((an.name, b, ch, 'excede length'))
        if an.loop and not all(ang_eq(x, y, ch) for x, y in zip(keys[0][1], keys[-1][1])):
            bad.append((an.name, b, ch, 'loop no cierra'))
    if an.name.endswith(('energy_pulse', 'activation', 'glitch')):
        for (b, ch), keys in an.tr.items():
            dflt = {'scale': O3, 'position': Z3, 'rotation': Z3}[ch]
            ref = base.get((b, ch), dflt) if b not in ('shock_ring', 'flash') else Z3
            if not all(ang_eq(x, y, ch) for x, y in zip(keys[-1][1], ref)) and not (b in ('shock_ring', 'flash')):
                bad.append((an.name, b, ch, f'estado final {keys[-1][1]} != idle {ref}'))
print('QC animaciones:', 'OK' if not bad else bad)

# ---------------------------------------------------------------- export bbmodel
def tree(g):
    return dict(name=g.name, origin=list(g.origin), rotation=list(g.rot), color=0, uuid=g.uuid, export=True,
                isOpen=g is root or g.name.startswith(('core', 'ring_tilt', 'frag_tilt')), locked=False,
                visibility=True, autouv=0,
                children=[c['uuid'] for c in g.cubes] + [tree(c) for c in g.children])


def bb_elem(e):
    u, v = e['uv']
    f = {k: dict(uv=[u, v, u + 2, v + 2], texture=0) for k in FACES}
    return dict(name=e['name'], box_uv=False, rescale=False, locked=False, render_order='default',
                allow_mirror_modeling=True, **{'from': e['fr']}, to=e['to'], autouv=0, color=0,
                origin=e['origin'], faces=f, type='cube', uuid=e['uuid'])


def bb_anim(an):
    ans = {}
    for (b, ch), keys in an.tr.items():
        g = next(x for x in GROUPS if x.name == b)
        a = ans.setdefault(g.uuid, dict(name=b, type='bone', keyframes=[]))
        for t, vec, ip in keys:
            a['keyframes'].append(dict(channel=ch, data_points=[dict(x=vec[0], y=vec[1], z=vec[2])], uuid=U(),
                                       time=t, color=-1, interpolation=ip))
    return dict(uuid=U(), name=an.name, loop='loop' if an.loop else 'once', override=False, length=an.length,
                snapping=24, selected=False, anim_time_update='', blend_weight='', start_delay='', loop_delay='',
                animators=ans)


bb = dict(meta=dict(format_version='4.10', creation_time=1794000000, model_format='free', box_uv=False),
          name='relic_hologram', model_identifier='relic_hologram', visible_box=[4, 4, 0],
          variable_placeholders='', variable_placeholder_buttons=[], timeline_setups=[], unhandled_root_fields={},
          resolution=dict(width=TEX, height=TEX), elements=[bb_elem(e) for e in ELEMS], outliner=[tree(root)],
          textures=[dict(path='../textures/relic_hologram.png', name='relic_hologram.png', folder='', namespace='',
                         id='0', width=TEX, height=TEX, uv_width=TEX, uv_height=TEX, particle=False,
                         use_as_default=True, layers_enabled=False, sync_to_project='', render_mode='default',
                         render_sides='auto', frame_time=1, frame_order_type='loop', frame_order='',
                         frame_interpolate=False, visible=True, internal=True, saved=True, uuid=U(),
                         source='data:image/png;base64,' + base64.b64encode(PNG).decode())],
          animations=[bb_anim(a) for a in ANIMS])
json.dump(bb, open(f'{BASE}/source/relic_hologram.bbmodel', 'w'), indent=1)

# ---------------------------------------------------------------- export geo (Bedrock 1.12.0, formato leido por GeckoLib)
bones = []


def walk(g):
    b = dict(name=g.name, pivot=list(g.origin))
    if g.parent:
        b['parent'] = g.parent.name
    if any(g.rot):
        b['rotation'] = list(g.rot)
    if g.cubes:
        cubes = []
        for e in g.cubes:
            u, v = e['uv']
            cubes.append(dict(origin=e['fr'], size=[round(t - f, 4) for f, t in zip(e['fr'], e['to'])],
                              uv={k: dict(uv=[u, v], uv_size=[2, 2]) for k in FACES}))
        b['cubes'] = cubes
    bones.append(b)
    for c in g.children:
        walk(c)


walk(root)
geo = {'format_version': '1.12.0', 'minecraft:geometry': [dict(
    description=dict(identifier='geometry.relic_hologram', texture_width=TEX, texture_height=TEX,
                     visible_bounds_width=4, visible_bounds_height=4, visible_bounds_offset=[0, 1, 0]),
    bones=bones)]}
json.dump(geo, open(f'{BASE}/export/geo/relic_hologram.geo.json', 'w'), indent=1)


def tfmt(t):
    return f'{t:.2f}'.rstrip('0').rstrip('.') if t % 1 else f'{t:.1f}'


anims = {}
for an in ANIMS:
    bn = {}
    for (b, ch), keys in an.tr.items():
        d = {}
        for t, vec, ip in keys:
            d[tfmt(t)] = vec if ip == 'linear' else {'post': vec, 'lerp_mode': 'catmullrom'}
        bn.setdefault(b, {})[ch] = d
    entry = dict(animation_length=an.length, bones=bn)
    if an.loop:
        entry = dict(loop=True, **entry)
    anims[an.name] = entry
json.dump({'format_version': '1.8.0', 'animations': anims},
          open(f'{BASE}/export/animations/relic_hologram.animation.json', 'w'), indent=1)

print('cubos:', len(ELEMS), '| huesos:', len(GROUPS), '| animaciones:', [a.name for a in ANIMS])

# ---------------------------------------------------------------- preview
from PIL import Image, ImageDraw, ImageFilter, ImageChops


def R(p, org, rot):
    rx, ry, rz = [math.radians(a) for a in rot]
    x, y, z = [p[i] - org[i] for i in range(3)]
    y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
    x, z = x * math.cos(ry) + z * math.sin(ry), -x * math.sin(ry) + z * math.cos(ry)
    x, y = x * math.cos(rz) - y * math.sin(rz), x * math.sin(rz) + y * math.cos(rz)
    return [x + org[0], y + org[1], z + org[2]]


def chain(g, p):
    while g:
        if any(g.rot):
            p = R(p, g.origin, g.rot)
        g = g.parent
    return p


def corners(fr, to):
    return [[x, y, z] for x in (fr[0], to[0]) for y in (fr[1], to[1]) for z in (fr[2], to[2])]


QUADS = [(0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4), (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)]


def render(yaw, pitch, size, scale, ref=True, tag_center=None):
    polys = []
    cy_, sy_ = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    cen = tag_center or C

    def view(p):
        x, y, z = p[0] - cen[0], p[1] - cen[1], p[2] - cen[2]
        x, z = x * cy_ + z * sy_, -x * sy_ + z * cy_
        y, z = y * cp - z * sp, y * sp + z * cp
        return x, y, z

    def addbox(corn, col, shade_base):
        vs = [view(c) for c in corn]
        for q in QUADS:
            pts = [vs[i] for i in q]
            d = sum(p[2] for p in pts) / 4
            a = (pts[1][0] - pts[0][0], pts[1][1] - pts[0][1], pts[1][2] - pts[0][2])
            b = (pts[3][0] - pts[0][0], pts[3][1] - pts[0][1], pts[3][2] - pts[0][2])
            nz = a[0] * b[1] - a[1] * b[0]
            sh = shade_base * (0.8 + 0.2 * min(1, abs(nz) / 2))
            polys.append((d, [(p[0], p[1]) for p in pts], col, sh))

    if ref:  # silueta de jugador de referencia (Steve)
        for fr, to in (((-4, 12, -2), (4, 24, 2)), ((-4, 24, -4), (4, 32, 4)), ((-8, 12, -2), (-4, 24, 2)),
                       ((4, 12, -2), (8, 24, 2)), ((-4, 0, -2), (0, 12, 2)), ((0, 0, -2), (4, 12, 2))):
            addbox(corners(fr, to), (70, 80, 95, 255), 1.0)
    for e in ELEMS:
        corn = [chain(e['group'], c) for c in corners(e['fr'], e['to'])]
        u, v = e['uv']
        col = PAL[(v // 8) * 8 + u // 8]
        addbox(corn, col, 1.0)
    polys.sort(key=lambda p: -p[0])
    W = size
    img = Image.new('RGBA', (W, W), (5, 8, 16, 255))
    layer = Image.new('RGBA', (W, W), (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer, 'RGBA')
    ov = Image.new('RGBA', (W, W), (0, 0, 0, 0))
    for d, pts, col, sh in polys:
        sp_ = [(W / 2 + x * scale, W / 2 - y * scale) for x, y in pts]
        c = (int(col[0] * sh), int(col[1] * sh), int(col[2] * sh), col[3])
        x0 = max(0, int(min(p[0] for p in sp_))); y0 = max(0, int(min(p[1] for p in sp_)))
        x1 = min(W, int(max(p[0] for p in sp_)) + 2); y1 = min(W, int(max(p[1] for p in sp_)) + 2)
        if x1 <= x0 or y1 <= y0:
            continue
        t = Image.new('RGBA', (x1 - x0, y1 - y0), (0, 0, 0, 0))
        ImageDraw.Draw(t).polygon([(p[0] - x0, p[1] - y0) for p in sp_], fill=c)
        img.alpha_composite(t, (x0, y0))
    glow = img.filter(ImageFilter.GaussianBlur(scale * 1.4))
    out = ImageChops.add(img.convert('RGB'), Image.eval(glow.convert('RGB'), lambda v: int(v * .6)))
    return out


A1 = render(160, 18, 900, 55)
A2 = render(90, 8, 900, 55)
A3 = render(200, 12, 900, 16, tag_center=(-2, 26, 4))
sheet = Image.new('RGB', (1800, 900 + 450), (5, 8, 16))
sheet.paste(A1, (0, 0)); sheet.paste(A2, (900, 0))
sheet.paste(A3.resize((450, 450), Image.LANCZOS), (0, 900))
sheet.paste(A3.resize((225, 225), Image.LANCZOS), (500, 900))
sheet.paste(A3.resize((112, 112), Image.LANCZOS), (760, 900))
sheet.save(f'{BASE}/preview/preview_idle.png')
print('preview ok')
