# PROMPT PARA LA IA QUE HARÁ EL MOD

Copia todo lo de abajo y pásalo a la IA, junto con la carpeta `reliquia_holografica/` (o el .zip).

---

Actúa como desarrollador senior de mods de Minecraft Forge. Quiero que **construyas tú el mod completo**, con archivos reales, sin darme tutoriales. Si necesitas algo de mí, pídeme solo esa cosa concreta y sigue con el resto.

## 1. Objetivo
Un mod para **Minecraft Java 1.20.1, Forge, Java 17**, que añada una **reliquia cosmética** (un ítem accesorio vía **Curios API**) que se muestre como un núcleo holográfico de luz azul flotando detrás del jugador, ligeramente sobre un hombro, con estelas de luz orbitales a su alrededor. El modelo, las texturas y las animaciones ya están hechos (ver sección 3). **No debes rehacerlos ni modificarlos.** Tu trabajo es todo lo demás: proyecto Gradle, registro del ítem, integración con Curios, renderizado, control de animaciones, brillo, lang, receta y recursos.

## 2. Reglas importantes
- **Verifica las versiones.** Elige y declara las versiones concretas y compatibles de Forge 1.20.1, Curios API y GeckoLib 4 para 1.20.1 (consúltalas, no las inventes ni las recuerdes de memoria). Si una API que menciono aquí no existe con ese nombre en esa versión, dime cuál es la equivalente real.
- No inventes compatibilidades: si algo no se puede hacer como pido, dilo y propón la alternativa más cercana.
- Código limpio, comentado donde no sea obvio, sin dependencias innecesarias. Debe compilar (`gradlew build`) y arrancar con `runClient`.
- Entrega la estructura completa del proyecto, y al final una lista corta de qué probar en el juego.

## 3. Assets existentes (no modificar)
Estructura de la carpeta entregada:
- `export/geo/relic_hologram.geo.json` — geometría (formato Bedrock 1.12.0), identificador `geometry.relic_hologram`.
- `export/animations/relic_hologram.animation.json` — animaciones (formato 1.8.0).
- `textures/relic_hologram.png` — textura 64x64.
- `textures/relic_hologram_glowing.png` — copia de la textura para la capa emisiva (brillo).
- `source/relic_hologram.bbmodel` — fuente de Blockbench (solo referencia; si el modelo se ve espejado o las rotaciones salen invertidas con los JSON, indícalo: se pueden reexportar desde Blockbench).

Colócalos donde corresponda según la convención de GeckoLib 4 (por ejemplo `assets/<modid>/geo/`, `animations/`, `textures/`) y ajusta rutas y `modid` tú mismo. Puedes elegir el modid (propón uno corto, en minúsculas).

### Huesos (jerarquía)
`relic_root` > `core` (`core_inner`, `core_mid`, `core_shell`, `core_debris`, `core_aura`) · `ring_tilt_N` > `ring_spin_N` (N = 1..6; 1-4 son estelas elípticas, 5-6 anillos finos) · `frag_tilt_a`/`b` > `frag_orbit_a`/`b` · `drift_01..08` · `shock_ring` · `flash`.

### Animaciones (nombres exactos)
| Nombre | Duración | Tipo | Uso |
|---|---|---|---|
| `animation.relic.idle` | 12 s | loop | Estado normal (equipada y activa) |
| `animation.relic.idle_dormant` | 6 s | loop | Estado inactivo/apagado |
| `animation.relic.activation` | 3 s | una vez | Al activarse; termina en la pose de `idle` |
| `animation.relic.deactivation` | 2.2 s | una vez | Al desactivarse; termina en la pose de `idle_dormant` |
| `animation.relic.energy_pulse` | 2.4 s | una vez | Pulso de energía puntual; termina en la pose de `idle` |
| `animation.relic.glitch` | 1 s | una vez | Parpadeo breve; termina en la pose de `idle` |

Notas técnicas del modelo:
- `shock_ring` y `flash` están **visibles en la pose por defecto**; todas las animaciones los dejan a escala 0, así que siempre debe haber una animación activa (nunca renderizar sin animación).
- El punto de anclaje del núcleo en coordenadas del modelo es (-6, 30, 8) píxeles: sobre un hombro y detrás del jugador (Z+ = espalda). Para el otro hombro hay que **espejar en X**. Haz configurable (config del mod) el hombro (izquierdo/derecho) y un offset/escala ajustable.
- El modelo es pequeño a propósito (unos 11 px de ancho en total). Expón una escala configurable.
- Textura con alfa: las piezas translúcidas (estelas, cáscara, aura) usan transparencia de la propia textura.

## 4. Funcionalidad que debes implementar
1. **Ítem accesorio Curios** (propón un slot adecuado, p. ej. `charm` o uno propio tipo "relic"/"back", y registra el tag/slot con los datos necesarios de Curios en datapack). Máximo 1 equipada. Sin textura de ítem complicada: usa un icono sencillo (puedes generar un PNG 16x16 azul con script) y modelo de ítem plano.
2. **Renderizado en el jugador** mediante el sistema de renderizado de Curios para accesorios (`ICurioRenderer` o el mecanismo equivalente de la versión que elijas) con **GeckoLib 4**. Debe verse en tercera persona y en el modelo del jugador de otros jugadores (multijugador), **no** tapar la vista en primera persona. Debe seguir la rotación del cuerpo y ajustarse al agacharse (sneak) como un accesorio de espalda/hombro; evita que atraviese la armadura o la capa de forma exagerada.
3. **Máquina de estados de animación** (AnimationController de GeckoLib):
   - Al equipar: `activation` → luego `idle`.
   - Al desequipar: no se renderiza más (si es viable, deja que se vea `deactivation` brevemente; si no, omítelo y dímelo).
   - Un comando o tecla configurable (propón: un keybind) que alterna entre estado activo (`idle`) y dormant (`activation`/`deactivation` + `idle_dormant`).
   - Disparar `energy_pulse` con una acción concreta (propón una: p. ej. al subir de nivel o con un comando `/relic pulse`), y `glitch` de forma ocasional aleatoria cada cierto intervalo configurable (por defecto 20-60 s) solo mientras está en `idle`.
   - Las transiciones entre animaciones deben ser suaves (cuidado: `activation`, `deactivation`, `energy_pulse` y `glitch` están diseñadas para empezar/terminar en poses compatibles con `idle`/`idle_dormant`).
4. **Brillo (glow).**
   - Renderiza el modelo con la capa emisiva: usa `textures/relic_hologram_glowing.png` con el mecanismo de capas brillantes de GeckoLib 4 (confirma el nombre de clase y la convención de sufijo de textura de la versión elegida), o, si no encaja con el renderizado de Curios, implementa el modelo en *fullbright* (luz máxima, sin sombreado) con `RenderType` translúcido/emisivo.
   - El objeto debe verse **luminoso incluso de noche y en cuevas**.
   - Comprueba y documenta cómo se comporta con shaders (Iris/Oculus) y, si un mod de bloom o de render avanzado puede añadir resplandor real, deja un punto de integración opcional sin hacerlo obligatorio. No introduzcas dependencias obligatorias de shaders.
5. **Obtención**: receta de crafteo sencilla pero temática (propón una con materiales vanilla) y entrada en la pestaña creativa.
6. **Lang** en español (es_es) e inglés (en_us). Nombre propuesto: "Núcleo Holográfico" / "Holographic Core".
7. **Rendimiento**: el modelo tiene ~750 cubos pequeños. Evita recalcular nada pesado cada tick; ofrece una opción de config para reducir calidad (p. ej. ocultar los fragmentos `drift_*` y las estelas más finas) si es técnicamente sencillo.

## 5. Qué entregar
- Proyecto Gradle completo y compilable (`build.gradle`, `mods.toml`, `pack.mcmeta`, código Java, recursos, datapack de Curios, lang, recetas).
- Los assets copiados en sus rutas correctas.
- Un `README` corto: cómo compilar, cómo probar y los parámetros de configuración.
- Una checklist final de pruebas: equipar/desequipar, activación/desactivación, sneak, primera persona, multijugador, de noche/cueva, y con/sin shaders.

Empieza ya: primero indica en 5 líneas máximo las versiones que elegiste y por qué, y luego genera el proyecto.
