# Reliquia holográfica v3 (núcleo de luz azul + estelas orbitales, tamaño reducido)

- `source/relic_hologram.bbmodel` — fuente editable (modelo + 6 animaciones + textura embebida). Abrir en Blockbench.
- `export/geo/relic_hologram.geo.json` y `export/animations/relic_hologram.animation.json` — formato Bedrock (geo 1.12.0 / anim 1.8.0), generados por script. Verifícalos al importarlos; si algo difiere, reexporta desde el .bbmodel con Blockbench.
- `textures/relic_hologram.png` (64x64) y `relic_hologram_glowing.png` (copia para capa emisiva/brillo).
- `preview/preview_idle.png` — render de control con jugador de referencia.
- `PROMPT_MOD_PARA_IA.md` — prompt listo para que otra IA construya el mod (Forge 1.20.1 + Curios + GeckoLib).
- `tools/build_relic.py` — regenera todo (`python3 build_relic.py`; escala global en `K`). `build_relic_v1.py` y `build_relic_v2.py` son versiones anteriores.

## Jerarquía
relic_root > core (core_inner, core_mid, core_shell, core_debris, core_aura) · ring_tilt_N > ring_spin_N (N=1..4 estelas elípticas con cola afilada, N=5..6 anillos finos) · frag_tilt_a/b > frag_orbit_a/b · drift_01..08 · shock_ring · flash

## Animaciones
`idle` (12 s, loop), `idle_dormant` (6 s, loop), `energy_pulse` (2.4 s), `activation` (3 s), `deactivation` (2.2 s, termina en dormant), `glitch` (1 s).

Notas: `shock_ring` y `flash` están visibles en la pose por defecto; todas las animaciones los fijan a escala 0. Núcleo en (-6, 30, 8): sobre un hombro y detrás del jugador (Z+ = espalda); para el otro hombro, espejar X. El brillo real lo da el renderizado del mod (capa emisiva / fullbright); el modelo aporta la textura emisiva y un aura translúcida (`core_aura`).
